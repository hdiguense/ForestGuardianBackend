(function(e,t,n,r){function i(r){if(!n[r]){if(!t[r]){if(e)return e(r);throw new Error("Cannot find module '"+r+"'")}var s=n[r]={exports:{}};t[r][0](function(e){var n=t[r][1][e];return i(n?n:e)},s,s.exports)}return n[r].exports}for(var s=0;s<r.length;s++)i(r[s]);return i})(typeof require!=="undefined"&&require,{"a1b5af78":[function(require,module,exports){
console.log(require('./foo')(5))
},{"./foo":"b8f69fa5"}],"b8f69fa5":[function(require,module,exports){
module.exports = function (n) { return n * 111 }
},{}]},{},["a1b5af78"])
//@ sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlcyI6WyJ3dW5kZXIvYmFyLmpzIiwiZm9vLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7QUNBQSJ9
