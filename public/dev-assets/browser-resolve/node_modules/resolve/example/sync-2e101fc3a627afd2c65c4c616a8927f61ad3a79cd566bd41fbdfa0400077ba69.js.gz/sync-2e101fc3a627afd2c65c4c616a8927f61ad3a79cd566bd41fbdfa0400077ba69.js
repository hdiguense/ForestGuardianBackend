var resolve = require('../');
var res = resolve.sync('tap', { basedir: __dirname });
console.log(res);
