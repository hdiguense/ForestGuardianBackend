module.exports = 'whatever'
