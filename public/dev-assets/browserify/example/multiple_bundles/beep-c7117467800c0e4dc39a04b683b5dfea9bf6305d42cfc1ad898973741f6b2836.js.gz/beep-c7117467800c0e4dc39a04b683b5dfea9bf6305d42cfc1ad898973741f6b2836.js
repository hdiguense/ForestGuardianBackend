var robot = require('./robot');
console.log(robot('beep'));
