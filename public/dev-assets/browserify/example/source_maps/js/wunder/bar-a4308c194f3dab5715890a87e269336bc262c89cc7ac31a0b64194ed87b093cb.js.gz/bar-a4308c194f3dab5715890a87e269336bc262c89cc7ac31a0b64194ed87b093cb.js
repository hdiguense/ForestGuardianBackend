console.log('bar line 1');
'use strict';

// this is a meaningless comment to add some lines

module.exports = function bar() {
  console.log('hello from bar line 7');
};
