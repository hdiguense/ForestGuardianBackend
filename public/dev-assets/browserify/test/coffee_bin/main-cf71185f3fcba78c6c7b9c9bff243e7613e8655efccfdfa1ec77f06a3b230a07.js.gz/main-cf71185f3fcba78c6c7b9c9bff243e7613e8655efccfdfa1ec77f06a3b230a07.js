(function() {
  console.log("hello world!");

  require('./x.coffee');

}).call(this);
