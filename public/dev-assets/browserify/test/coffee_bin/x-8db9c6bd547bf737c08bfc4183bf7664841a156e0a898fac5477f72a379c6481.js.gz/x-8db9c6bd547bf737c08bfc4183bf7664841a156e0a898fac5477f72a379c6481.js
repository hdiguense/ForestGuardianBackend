(function() {
  console.log("from x!");

}).call(this);
