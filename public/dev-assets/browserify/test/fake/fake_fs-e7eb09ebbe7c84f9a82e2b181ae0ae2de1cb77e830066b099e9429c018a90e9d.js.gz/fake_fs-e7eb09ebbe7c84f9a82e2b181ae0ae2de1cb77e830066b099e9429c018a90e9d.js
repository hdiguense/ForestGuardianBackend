exports.party = function () { return 'PaRtY!1!1!' };
