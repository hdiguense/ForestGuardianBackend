module.exports = 'browser';
