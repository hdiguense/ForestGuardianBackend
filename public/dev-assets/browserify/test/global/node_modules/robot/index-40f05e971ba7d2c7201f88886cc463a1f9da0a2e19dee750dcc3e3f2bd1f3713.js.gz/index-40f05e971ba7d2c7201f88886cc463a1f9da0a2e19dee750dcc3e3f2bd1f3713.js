module.exports = require('./lib/beep');
