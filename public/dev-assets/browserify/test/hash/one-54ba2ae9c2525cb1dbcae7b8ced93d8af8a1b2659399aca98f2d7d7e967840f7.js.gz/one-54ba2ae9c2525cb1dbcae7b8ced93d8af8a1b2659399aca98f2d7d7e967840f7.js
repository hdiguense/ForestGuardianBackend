// FILE CONTENTS
module.exports = 111 * require('./other.js');
