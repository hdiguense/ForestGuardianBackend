module.exports = require('../ignored/skip.js');
