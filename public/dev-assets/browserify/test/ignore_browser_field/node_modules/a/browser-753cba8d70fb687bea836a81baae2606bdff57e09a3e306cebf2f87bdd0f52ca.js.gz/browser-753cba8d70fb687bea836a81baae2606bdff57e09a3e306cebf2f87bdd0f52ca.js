module.exports = 'A:BROWSER'
