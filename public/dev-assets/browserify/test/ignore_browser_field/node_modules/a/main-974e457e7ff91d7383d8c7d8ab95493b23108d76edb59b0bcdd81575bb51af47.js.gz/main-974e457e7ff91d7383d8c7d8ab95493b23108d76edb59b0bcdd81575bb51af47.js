module.exports = 'A:NODE'
