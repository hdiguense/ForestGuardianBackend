module.exports = ('b:' + require('./x.js')).toUpperCase();
