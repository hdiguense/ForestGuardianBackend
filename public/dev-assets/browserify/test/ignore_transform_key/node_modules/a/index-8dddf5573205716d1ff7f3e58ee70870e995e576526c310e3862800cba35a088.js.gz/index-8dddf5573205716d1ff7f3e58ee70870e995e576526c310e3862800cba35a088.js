module.exports = 'good';
