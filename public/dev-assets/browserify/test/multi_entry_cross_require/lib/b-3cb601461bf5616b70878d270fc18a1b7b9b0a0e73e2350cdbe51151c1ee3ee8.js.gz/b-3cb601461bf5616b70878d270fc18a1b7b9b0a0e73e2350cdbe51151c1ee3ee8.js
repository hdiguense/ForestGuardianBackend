times++;

module.exports.foo = function() {
  times++;
};
