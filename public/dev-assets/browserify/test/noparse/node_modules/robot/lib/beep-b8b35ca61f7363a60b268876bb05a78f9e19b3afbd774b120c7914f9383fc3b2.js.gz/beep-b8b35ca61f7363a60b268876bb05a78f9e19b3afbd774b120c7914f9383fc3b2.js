module.exports = {
    beep: true,
    boop: require('./boop')
};
