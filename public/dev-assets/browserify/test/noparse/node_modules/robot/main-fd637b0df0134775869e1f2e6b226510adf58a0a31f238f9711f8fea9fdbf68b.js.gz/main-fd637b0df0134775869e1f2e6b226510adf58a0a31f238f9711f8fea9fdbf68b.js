module.exports = {
    robot: true,
    beep: require('./lib/beep')
};
