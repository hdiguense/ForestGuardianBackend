module.exports = function() {
 console.log("b a")
};
