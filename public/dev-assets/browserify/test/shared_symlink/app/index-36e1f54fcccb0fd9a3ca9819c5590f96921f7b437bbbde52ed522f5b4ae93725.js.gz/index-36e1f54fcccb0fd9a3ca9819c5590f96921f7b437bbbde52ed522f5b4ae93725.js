module.exports = require('shared') + require('foo')
