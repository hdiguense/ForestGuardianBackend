module.exports = function (cb) {
  cb(require('./one'), require('./two'));
};
