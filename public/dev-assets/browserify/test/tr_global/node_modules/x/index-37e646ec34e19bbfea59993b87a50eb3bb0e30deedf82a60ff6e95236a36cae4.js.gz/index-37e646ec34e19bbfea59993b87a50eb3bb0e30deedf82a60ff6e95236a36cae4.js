module.exports = 111 * VAR
