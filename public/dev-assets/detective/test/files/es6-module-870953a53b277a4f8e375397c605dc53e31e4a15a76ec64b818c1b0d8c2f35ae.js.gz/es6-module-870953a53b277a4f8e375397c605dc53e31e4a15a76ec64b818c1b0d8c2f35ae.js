var a = require('a');

export default function () {
    var b = require('b');
}
