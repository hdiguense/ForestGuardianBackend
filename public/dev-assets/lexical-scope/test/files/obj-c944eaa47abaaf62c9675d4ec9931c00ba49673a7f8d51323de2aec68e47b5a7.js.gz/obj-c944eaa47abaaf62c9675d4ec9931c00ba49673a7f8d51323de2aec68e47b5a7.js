module.exports = {foo: bar}
