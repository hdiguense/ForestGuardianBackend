function foo() {
  return {
    bar: true
  }
}
