require('../foo');
console.log('xyz');
