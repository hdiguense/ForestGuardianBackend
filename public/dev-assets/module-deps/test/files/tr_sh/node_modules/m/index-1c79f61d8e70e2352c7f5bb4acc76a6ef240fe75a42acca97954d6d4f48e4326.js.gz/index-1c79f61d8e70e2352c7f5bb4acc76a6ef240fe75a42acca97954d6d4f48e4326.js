var AAA = 200, BBB = 300;

module.exports = function (x) { return AAA + BBB + x }
