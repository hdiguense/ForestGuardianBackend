var decrement = require('./lib/decrement');

exports.calc = function (x) { return decrement(x) - GGG - GGG }
