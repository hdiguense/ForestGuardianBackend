module.exports = function (x) { return x - GGG }
