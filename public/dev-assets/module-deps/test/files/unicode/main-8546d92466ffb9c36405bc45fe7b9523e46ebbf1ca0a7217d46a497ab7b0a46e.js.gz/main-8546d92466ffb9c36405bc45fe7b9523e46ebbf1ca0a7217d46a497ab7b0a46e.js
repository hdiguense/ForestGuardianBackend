var π = require('./foo');
console.log('main: ' + foo(5));
